


<?php $__env->startSection('content'); ?>


    <h1>  <small> You are currently viewing Product: </small> <?php echo e($service->service_name); ?>   </h1>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel Projects\restravels\resources\views/services/show.blade.php ENDPATH**/ ?>