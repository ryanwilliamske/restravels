

<?php $__env->startSection('title', 'Search Results'); ?>


<?php $__env->startSection('content'); ?>
    
     <div class="search-results-container container">

 
         <h1 class="d-flex justify-content-center mb-5"> Search Results </h1>

         <p class="results-count"> <?php echo e($services->total()); ?> result(s) for "<?php echo e(request()->service); ?>" </p>
         <table class="table" >
            <thead>
                <tr>
                <th scope="col">Service Name</th>
                <th scope="col">Description</th>
                <th scope="col">Price</th>
                </tr>
            </thead>
            <tbody>
         
            <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                <th scope="row"> <a href="<?php echo e(route('services.show', $service->id)); ?>"> <?php echo e($service->service_name); ?> </a> </th>

                 <td> <a href="<?php echo e(route('services.show', $service->id)); ?>"><?php echo e(\Illuminate\Support\Str::limit($service->service_descript, 80)); ?> </a> </td> 
                <td> <?php echo e($service->service_price); ?> </td> 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div style="tex-align: left">No items found</div>
            <?php endif; ?>


                  </tbody>
        </table>
         
        
        <?php echo e($services->appends( request()->input())->links()); ?>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel Projects\restravels\resources\views/results_page.blade.php ENDPATH**/ ?>