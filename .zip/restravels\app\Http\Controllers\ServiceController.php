<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Service;

class ServiceController extends Controller
{
    public function search()
    {
        request()->validate([
            'service' => 'required|min:3',
        ]);

        $service = request()->service;
        // $services = Service::where('service_name', 'like', "%$service%")
        // ->orWhere('service_descript', 'like', "%$service%")
        // ->paginate(10);

        $services = Service::search($service)->paginate(10);
        
        return view('results_page', compact('services'));
    }

    public function show(Service $service)
    {
        $service = Service::where('id', $service->id)->first();
        return view('services.show', compact('service'));
    }
}

